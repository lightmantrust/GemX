# FusionAI System Manual

## Overview
- Multi-agent architecture
- Risk controls
- Subscription API

This package includes the full FusionAI system components:
- Multi-agent AI Python codebase
- Documentation (PDF)
- Docker + Kubernetes YAMLs
- GitHub Repo Packaging Instructions
- Deployment Guidelines
- System Manual

Property of Lightman Trust Group Ltd.
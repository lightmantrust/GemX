# GemX Setup Guide

Instructions to install macros, enable Excel scripting, and use valuation tools.
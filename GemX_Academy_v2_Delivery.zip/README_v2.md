# GemX Academy Excel Setup (v2)

1. Open `GemX_Excel_Dashboard_v2.xlsm` in Microsoft Excel.
2. Enable Macros when prompted.
3. Use navigation tabs for each gemstone (Rough / Polished).
4. Tokenization features: Go to "Control Panel" tab > NFT/Token switch.
5. Pricing tables can be updated manually or via API connection.
6. Save changes. Export SKR or Certificate with macro buttons.